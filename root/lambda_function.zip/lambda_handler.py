import json
import boto3
import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq
from io import BytesIO
import base64

s3 = boto3.client('s3')

def lambda_handler(event, context):
    for record in event['records']:
        payload = base64.b64decode(record['data']).decode('utf-8')
        data = json.loads(payload)
        
        # Convert JSON to Pandas DataFrame
        df = pd.DataFrame(data)
        
        # Convert DataFrame to Parquet format
        parquet_file = BytesIO()
        table = pq.write_table(pa.Table.from_pandas(df), parquet_file, compression='snappy')
        
        # Store Parquet data in S3
        bucket_name = 'prashik123'  # Update with your S3 bucket name
        s3_key = 'paraquatdata/'      # Update with your desired path
        s3.put_object(Bucket=bucket_name, Key=s3_key, Body=parquet_file.getvalue())
        
        print(f"Stored Parquet file in S3: s3://{bucket_name}/{s3_key}")
    
    return {'statusCode': 200, 'body': json.dumps('Data stored successfully')}

